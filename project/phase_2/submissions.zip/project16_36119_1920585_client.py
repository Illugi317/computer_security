import socket
import json
from time import sleep

HEADER = 32
PORT = 5050
SERVER = socket.gethostbyname(socket.gethostname())
ADDR = (SERVER, PORT)
FORMAT = 'utf-8'
DISCONNECT_MSG = "/disconnect"
DELAY = 2

# Sends a message to the server
def send_msg(msg):
    message = msg.encode(FORMAT)
    msg_length = len(msg)
    send_length = str(msg_length).encode(FORMAT)
    send_length += b' ' * (HEADER - len(send_length))
    client.send(send_length)
    client.send(message)
    print(client.recv(2048).decode(FORMAT))

# Request client input
print("Enter your ID: ")
id = input()
print("Enter your password: ")
pw = input()

dic = {
    "id": id, 
    "password": pw, 
    "server": 
    {   "ip": SERVER, 
        "port": PORT
    },
    "actions": 
    {   "delay": DELAY,
        "steps": [ 
            "/increase",
            "/decrease"
            ]
    }
}

# Create JSON file
data = json.dumps(dic,indent=3)

# Connect to server and send inital data
client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
client.connect(ADDR)
send_msg(data)


# Set this to true to automatically run actions
steps = False
if steps:
    for s in dic["actions"]["steps"]:
        send_msg(s)
        sleep(DELAY)
        send_msg(DISCONNECT_MSG)
else:
    x = ""
    while x != DISCONNECT_MSG:
        x = input()
        send_msg(x)