import socket
import threading
import json

HEADER = 32
PORT = 5050
SERVER = socket.gethostbyname(socket.gethostname())
ADDR = (SERVER, PORT)
FORMAT = 'utf-8'
DISCONNECT_MSG = "/disconnect"
INCREASE_MSG = "/increase"
DECREASE_MSG = "/decrease"

server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server.bind(ADDR)

active_users = {}
user_counter = {}

# Handle client input
def handle_client(conn, addr):
    print(f"[NEW CONNECTION] {addr} connected")
    connected = True
    while connected:
        msg_length = conn.recv(HEADER).decode(FORMAT)
        if msg_length:
            msg_length = int(msg_length)
            msg = conn.recv(msg_length).decode(FORMAT)

            if msg == DISCONNECT_MSG:
                connected = False
                print(f"[DISCONNECT] User with ID {id} and on {addr} has been disconnected.")
                conn.send(f"User with ID {id} and on {addr} has been disconnected".encode(FORMAT))
                id = active_users[addr]["id"]
                del active_users[addr]
                same_id = [u for u in active_users.values() if u['id'] == id]
                if len(same_id) == 0:
                   del user_counter[id]
            elif msg == INCREASE_MSG:
                id = active_users[addr]["id"]
                user_counter[id] += 1
                print(f"[INCREASE] User with ID {id} increased counter by 1. New value of counter: {user_counter[id]}")
                conn.send(f"User with ID {id} increased counter by 1. New value of counter: {user_counter[id]}".encode(FORMAT))
            elif msg == DECREASE_MSG:
                id = active_users[addr]["id"]
                user_counter[id] -= 1
                print(f"[DECREASE] User with ID {id} decreased counter by 1. New value of counter: {user_counter[id]}")
                conn.send(f"User with ID {id} decreased counter by 1. New value of counter: {user_counter[id]}".encode(FORMAT))
            else:
                try:
                    data = json.loads(msg)
                    # Gets all the IDs of clients that are registered using the same ID and different password
                    same_id = [u for u in active_users.values() if u['id'] == data['id'] and u['password'] != data['password']]
                    if len(same_id) > 0:
                        conn.send("Given ID is already used with a different password".encode(FORMAT))
                        connected = False
                    else:
                        conn.send("Logged in succesfully\nExisting commands: \'/increase\', \'/decrease\' and \'/disconnect\'".encode(FORMAT))
                        active_users[addr] = data
                        if user_counter.get(data['id']) == None:
                            user_counter[data['id']] = 0
                except ValueError:
                    print(f"[{addr}] {msg}")
                    conn.send(f"\'{msg}\' command was not recognized.".encode(FORMAT))
    conn.close()

# Start the server
def start():
    server.listen()
    print(f"[LISTENING] Server is listening on {SERVER}")
    while True:
        conn, addr = server.accept()
        thread = threading.Thread(target=handle_client, args=(conn, addr))
        thread.start()
        print(f"[ACTIVE CONNECTIONS] {threading.activeCount() - 1}")

print("[STARTING] Starting server...")
start()